const pool = require('../config/database.js');

const getAllTanaman = () => {
    const SQLQuery = 'SELECT * FROM tanaman'
    
    return pool.execute(SQLQuery);
}

const getTanamanDetails = (nama_tanaman) => {
    const SQLQuery = `
    SELECT 
        t.*, 
        i.* 
    FROM 
        tanaman t
    JOIN 
        info_tambahan i
    ON 
        t.nama = i.nama_tanaman
    WHERE 
        t.nama = ?`;

    return pool.execute(SQLQuery, [nama_tanaman]);
}

const getResep = (penyakit) => {
    const SQLQuery = `SELECT * FROM info_tambahan WHERE penyakit = '${penyakit}'`

    return pool.execute(SQLQuery);
}

const searchTanaman = (search, filter) => {
    const order = 'ASC';

    const SQLQuery = 
        `SELECT DISTINCT t.nama, t.gambar 
        FROM tanaman t
        LEFT JOIN info_tambahan i ON t.nama = i.nama_tanaman
        WHERE t.nama LIKE ? AND i.penyakit LIKE ?
        ORDER BY t.nama ${order.toUpperCase() === 'DESC' ? 'DESC' : 'ASC'}`

    return pool.execute(SQLQuery, [`%${search || ''}%`, `%${filter || ''}%`]);
}

module.exports = { 
    getAllTanaman, 
    getTanamanDetails, 
    getResep,
    searchTanaman
}